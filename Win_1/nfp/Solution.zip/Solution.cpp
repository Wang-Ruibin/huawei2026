#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <fcntl.h>
#include <unistd.h>

#ifndef F_SETPIPE_SZ
#define F_SETPIPE_SZ 1031
#endif

#if defined(_WIN32)
#include <cstdarg>
inline int fcntl(int, int, ...)
{
    return -1;
}
#endif

struct Vector2D;
struct Polygon;
class CellGrid;

using namespace std;

const double EPS = 1e-12;
const long double EPS_LD = 1e-18L;
const double SIDE_EPS = 1e-10;
const double FINAL_NUDGE = 1e-9;

struct Vector2D
{
    double x, y;
    Vector2D(double x = 0, double y = 0) : x(x), y(y) {}

    Vector2D operator-(const Vector2D &other) const { return Vector2D(x - other.x, y - other.y); }
    Vector2D operator+(const Vector2D &other) const { return Vector2D(x + other.x, y + other.y); }
    Vector2D operator*(double scalar) const { return Vector2D(x * scalar, y * scalar); }
    Vector2D operator/(double scalar) const { return Vector2D(x / scalar, y / scalar); }
    Vector2D &operator+=(const Vector2D &other)
    {
        x += other.x;
        y += other.y;
        return *this;
    }
    double Dot(const Vector2D &other) const { return x * other.x + y * other.y; }
    double Cross(const Vector2D &other) const { return x * other.y - y * other.x; }
    double LengthSquared() const { return x * x + y * y; }
};

struct Polygon
{
    vector<Vector2D> vertices;
    Polygon() = default;
};

struct BBox
{
    double minX = 0, maxX = 0, minY = 0, maxY = 0;
};

struct ConvexCell
{
    vector<Vector2D> vertices;
    BBox box;
};

struct BoundarySegment
{
    Vector2D a, b, outward;
    BBox box;
};

struct BoundaryPoint
{
    Vector2D p, outward;
};

struct ConvexifiedPolygon
{
    vector<Vector2D> convex;
    int contourCount = 0;
};

struct SkeletonStep
{
    Vector2D a, b;
};

int n1, n2, m;
Polygon polygon1, polygon2;
vector<Vector2D> testCases;

ConvexifiedPolygon convexified1, convexified2;
vector<vector<Vector2D>> convexPieces1, convexPieces2;
vector<ConvexCell> overlapCells;
vector<BoundarySegment> boundarySegments;
vector<BoundaryPoint> boundaryPoints;
vector<Vector2D> paperBoundaryVertices;
vector<SkeletonStep> paperSkeleton;
bool paperBoundaryReady = false;
bool usePaperBoundary = false;
bool polygon1StrictConvex = false;
bool polygon2StrictConvex = false;
bool baseDataReady = false;
bool boundaryDataReady = false;

// ========== 几何基础 ==========
long double CrossLD(const Vector2D &a, const Vector2D &b)
{
    return (long double)a.x * b.y - (long double)a.y * b.x;
}
long double CrossLD(const Vector2D &a, const Vector2D &b, const Vector2D &c)
{
    return CrossLD(b - a, c - a);
}

double SignedArea(const vector<Vector2D> &pts)
{
    long double area = 0;
    for (size_t i = 0; i < pts.size(); ++i)
        area += CrossLD(pts[i], pts[(i + 1) % pts.size()]);
    return (double)(area * 0.5L);
}

void NormalizeCCW(vector<Vector2D> &pts)
{
    if (pts.size() >= 3 && SignedArea(pts) < 0)
        reverse(pts.begin(), pts.end());
}

BBox BuildBBox(const vector<Vector2D> &pts)
{
    BBox box;
    if (pts.empty())
        return box;
    box.minX = box.maxX = pts[0].x;
    box.minY = box.maxY = pts[0].y;
    for (size_t i = 1; i < pts.size(); ++i)
    {
        box.minX = min(box.minX, pts[i].x);
        box.maxX = max(box.maxX, pts[i].x);
        box.minY = min(box.minY, pts[i].y);
        box.maxY = max(box.maxY, pts[i].y);
    }
    return box;
}

bool SamePoint(const Vector2D &a, const Vector2D &b)
{
    return fabs(a.x - b.x) <= EPS && fabs(a.y - b.y) <= EPS;
}

bool PointLess(const Vector2D &a, const Vector2D &b)
{
    if (fabs(a.x - b.x) > EPS)
        return a.x < b.x;
    return a.y < b.y - EPS;
}

bool PointLessYX(const Vector2D &a, const Vector2D &b)
{
    if (fabs(a.y - b.y) > EPS)
        return a.y < b.y;
    return a.x < b.x - EPS;
}

// ========== 凸包 ==========
// ========== 三角剖分 ==========
bool IsConvexVertex(const Vector2D &prev, const Vector2D &cur, const Vector2D &next)
{
    return CrossLD(cur - prev, next - cur) > 0;
}

bool PointInTriangleNonStrict(const Vector2D &p, const Vector2D &a, const Vector2D &b, const Vector2D &c)
{
    long double c1 = CrossLD(a, b, p);
    long double c2 = CrossLD(b, c, p);
    long double c3 = CrossLD(c, a, p);
    return c1 >= 0 && c2 >= 0 && c3 >= 0;
}

vector<vector<Vector2D>> TriangulatePolygon(const Polygon &poly)
{
    vector<Vector2D> pts = poly.vertices;
    NormalizeCCW(pts);
    vector<vector<Vector2D>> result;
    if (pts.size() < 3)
        return result;
    vector<int> idx(pts.size());
    for (size_t i = 0; i < pts.size(); ++i)
        idx[i] = (int)i;
    while (idx.size() > 3)
    {
        bool found = false;
        size_t sz = idx.size();
        for (size_t i = 0; i < sz; ++i)
        {
            int prev = idx[(i + sz - 1) % sz];
            int cur = idx[i];
            int next = idx[(i + 1) % sz];
            if (!IsConvexVertex(pts[prev], pts[cur], pts[next]))
                continue;
            bool contains = false;
            for (size_t j = 0; j < sz; ++j)
            {
                int other = idx[j];
                if (other == prev || other == cur || other == next)
                    continue;
                if (PointInTriangleNonStrict(pts[other], pts[prev], pts[cur], pts[next]))
                {
                    contains = true;
                    break;
                }
            }
            if (contains)
                continue;
            result.push_back({pts[prev], pts[cur], pts[next]});
            idx.erase(idx.begin() + i);
            found = true;
            break;
        }
        if (!found)
        {
            result.clear();
            return result;
        }
    }
    result.push_back({pts[idx[0]], pts[idx[1]], pts[idx[2]]});
    return result;
}

vector<Vector2D> SimplifyClosedPolygon(vector<Vector2D> pts)
{
    vector<Vector2D> cleaned;
    for (const Vector2D &p : pts)
    {
        if (!cleaned.empty() && SamePoint(cleaned.back(), p))
            continue;
        cleaned.push_back(p);
    }
    while (cleaned.size() >= 2 && SamePoint(cleaned.front(), cleaned.back()))
        cleaned.pop_back();

    bool changed = true;
    while (changed && cleaned.size() >= 3)
    {
        changed = false;
        vector<Vector2D> next;
        size_t n = cleaned.size();
        for (size_t i = 0; i < n; ++i)
        {
            const Vector2D &prev = cleaned[(i + n - 1) % n];
            const Vector2D &cur = cleaned[i];
            const Vector2D &nxt = cleaned[(i + 1) % n];
            long double cr = CrossLD(cur - prev, nxt - cur);
            if (fabsl(cr) <= EPS_LD)
            {
                changed = true;
                continue;
            }
            next.push_back(cur);
        }
        cleaned.swap(next);
    }
    return cleaned;
}

bool IsStrictlyConvexPolygon(const vector<Vector2D> &pts)
{
    if (pts.size() < 3)
        return false;
    int n = (int)pts.size();
    for (int i = 0; i < n; ++i)
    {
        long double cr = CrossLD(pts[(i + 1) % n] - pts[i], pts[(i + 2) % n] - pts[(i + 1) % n]);
        if (cr <= EPS_LD)
            return false;
    }
    return true;
}

bool FindSharedReversedEdge(const vector<Vector2D> &a, const vector<Vector2D> &b, int &ia, int &jb)
{
    int na = (int)a.size();
    int nb = (int)b.size();
    for (int i = 0; i < na; ++i)
    {
        const Vector2D &a0 = a[i];
        const Vector2D &a1 = a[(i + 1) % na];
        for (int j = 0; j < nb; ++j)
        {
            const Vector2D &b0 = b[j];
            const Vector2D &b1 = b[(j + 1) % nb];
            if (SamePoint(a0, b1) && SamePoint(a1, b0))
            {
                ia = i;
                jb = j;
                return true;
            }
        }
    }
    return false;
}

vector<Vector2D> BuildMergedPolygon(const vector<Vector2D> &a, const vector<Vector2D> &b, int ia, int jb)
{
    vector<Vector2D> merged;
    int na = (int)a.size();
    int nb = (int)b.size();

    merged.push_back(a[ia]);

    int cur = (jb + 2) % nb;
    while (true)
    {
        merged.push_back(b[cur]);
        if (cur == jb)
            break;
        cur = (cur + 1) % nb;
    }

    cur = (ia + 2) % na;
    while (true)
    {
        merged.push_back(a[cur]);
        if (cur == ia)
            break;
        cur = (cur + 1) % na;
    }

    if (!merged.empty() && SamePoint(merged.front(), merged.back()))
        merged.pop_back();
    return SimplifyClosedPolygon(merged);
}

bool TryMergeConvexPieces(const vector<Vector2D> &a, const vector<Vector2D> &b, vector<Vector2D> &merged)
{
    int ia = -1, jb = -1;
    if (!FindSharedReversedEdge(a, b, ia, jb))
        return false;
    merged = BuildMergedPolygon(a, b, ia, jb);
    return IsStrictlyConvexPolygon(merged);
}

int PrevIndex(int i, int n)
{
    return (i + n - 1) % n;
}

int NextIndex(int i, int n)
{
    return (i + 1) % n;
}

int SideSign(const Vector2D &a, const Vector2D &b, const Vector2D &p)
{
    long double v = CrossLD(b - a, p - a);
    if (v > EPS_LD)
        return 1;
    if (v < -EPS_LD)
        return -1;
    return 0;
}

bool SameSideOfLine(const Vector2D &a, const Vector2D &b, const vector<Vector2D> &pts)
{
    int sign = 0;
    for (const Vector2D &p : pts)
    {
        int s = SideSign(a, b, p);
        if (s == 0)
            continue;
        if (sign == 0)
            sign = s;
        else if (sign != s)
            return false;
    }
    return true;
}

bool IsReflexVertexAt(const vector<Vector2D> &poly, int idx)
{
    int n = (int)poly.size();
    const Vector2D &prev = poly[PrevIndex(idx, n)];
    const Vector2D &cur = poly[idx];
    const Vector2D &next = poly[NextIndex(idx, n)];
    return CrossLD(cur - prev, next - cur) < -EPS_LD;
}

vector<pair<int, int>> CollectConcaveRuns(const vector<Vector2D> &poly)
{
    int n = (int)poly.size();
    vector<int> isReflex(n, 0);
    for (int i = 0; i < n; ++i)
    {
        if (IsReflexVertexAt(poly, i))
            isReflex[i] = 1;
    }
    vector<pair<int, int>> runs;
    int count = 0;
    for (int v : isReflex)
        count += v;
    if (count == 0)
        return runs;

    int start = -1;
    for (int i = 0; i < n; ++i)
    {
        int prev = PrevIndex(i, n);
        if (isReflex[i] && !isReflex[prev])
        {
            start = i;
            int end = i;
            while (isReflex[NextIndex(end, n)])
                end = NextIndex(end, n);
            runs.push_back({start, end});
        }
    }
    return runs;
}

bool TryPaperCutForRun(const vector<Vector2D> &poly, int firstReflex, int lastReflex,
                       int &leftKeep, int &rightKeep, int &removed)
{
    int n = (int)poly.size();
    leftKeep = PrevIndex(firstReflex, n);
    rightKeep = NextIndex(lastReflex, n);
    int guard = 0;
    while (guard++ < 4 * n)
    {
        bool ok = true;
        vector<Vector2D> checkPts = {
            poly[NextIndex(leftKeep, n)],
            poly[PrevIndex(leftKeep, n)],
            poly[PrevIndex(rightKeep, n)]};
        if (!SameSideOfLine(poly[leftKeep], poly[rightKeep], checkPts))
        {
            leftKeep = PrevIndex(leftKeep, n);
            ok = false;
        }
        if (leftKeep == rightKeep)
            break;
        if (ok)
            break;
    }
    guard = 0;
    while (guard++ < 4 * n)
    {
        bool ok = true;
        vector<Vector2D> checkPts = {
            poly[PrevIndex(leftKeep, n)],
            poly[NextIndex(rightKeep, n)],
            poly[PrevIndex(rightKeep, n)]};
        if (!SameSideOfLine(poly[leftKeep], poly[rightKeep], checkPts))
        {
            rightKeep = NextIndex(rightKeep, n);
            ok = false;
        }
        if (leftKeep == rightKeep)
            break;
        if (ok)
            break;
    }

    if (leftKeep == rightKeep)
        return false;
    removed = 0;
    for (int i = NextIndex(leftKeep, n); i != rightKeep; i = NextIndex(i, n))
        ++removed;
    return removed > 0;
}

bool FindPaperConvexificationCut(const vector<Vector2D> &poly, int &leftKeep, int &rightKeep)
{
    vector<pair<int, int>> runs = CollectConcaveRuns(poly);
    if (runs.empty())
        return false;

    bool found = false;
    int bestLeft = -1, bestRight = -1;
    int bestRemoved = numeric_limits<int>::max();
    for (const auto &run : runs)
    {
        int candLeft = -1, candRight = -1, removed = 0;
        if (!TryPaperCutForRun(poly, run.first, run.second, candLeft, candRight, removed))
            continue;
        if (removed < bestRemoved)
        {
            bestRemoved = removed;
            bestLeft = candLeft;
            bestRight = candRight;
            found = true;
        }
    }
    if (!found)
        return false;
    leftKeep = bestLeft;
    rightKeep = bestRight;
    return true;
}

vector<Vector2D> ExtractChainInclusive(const vector<Vector2D> &poly, int leftKeep, int rightKeep)
{
    vector<Vector2D> chain;
    int n = (int)poly.size();
    int idx = leftKeep;
    while (true)
    {
        chain.push_back(poly[idx]);
        if (idx == rightKeep)
            break;
        idx = NextIndex(idx, n);
    }
    return chain;
}

vector<Vector2D> BuildRemainingAfterCut(const vector<Vector2D> &poly, int leftKeep, int rightKeep)
{
    vector<Vector2D> remain;
    int n = (int)poly.size();
    remain.push_back(poly[leftKeep]);
    int idx = rightKeep;
    while (idx != leftKeep)
    {
        remain.push_back(poly[idx]);
        idx = NextIndex(idx, n);
    }
    return SimplifyClosedPolygon(remain);
}

ConvexifiedPolygon BuildConvexifiedPolygonPaper(const Polygon &poly)
{
    ConvexifiedPolygon result;
    vector<Vector2D> current = SimplifyClosedPolygon(poly.vertices);
    NormalizeCCW(current);
    int guard = 0;
    while (current.size() >= 3 && !IsStrictlyConvexPolygon(current) && guard++ < 256)
    {
        int leftKeep = -1, rightKeep = -1;
        if (!FindPaperConvexificationCut(current, leftKeep, rightKeep))
            break;

        ++result.contourCount;

        vector<Vector2D> next = BuildRemainingAfterCut(current, leftKeep, rightKeep);
        if (next.size() >= current.size())
            break;
        current.swap(next);
        NormalizeCCW(current);
    }

    result.convex = current;
    NormalizeCCW(result.convex);
    return result;
}

bool PointOnSegmentNonStrict(const Vector2D &p, const Vector2D &a, const Vector2D &b)
{
    if (fabsl(CrossLD(b - a, p - a)) > 1e-12L)
        return false;
    long double dot1 = (long double)(p.x - a.x) * (p.x - b.x);
    long double dot2 = (long double)(p.y - a.y) * (p.y - b.y);
    return dot1 <= 1e-12L && dot2 <= 1e-12L;
}

bool PointInSimplePolygonStrict(const Vector2D &p, const vector<Vector2D> &poly)
{
    if (poly.size() < 3)
        return false;
    for (size_t i = 0; i < poly.size(); ++i)
    {
        if (PointOnSegmentNonStrict(p, poly[i], poly[(i + 1) % poly.size()]))
            return false;
    }

    bool inside = false;
    for (size_t i = 0, j = poly.size() - 1; i < poly.size(); j = i++)
    {
        const Vector2D &a = poly[j];
        const Vector2D &b = poly[i];
        bool intersect = ((a.y > p.y) != (b.y > p.y)) &&
                         (p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x);
        if (intersect)
            inside = !inside;
    }
    return inside;
}

void BuildConvexDecompositionPaperRecursive(const vector<Vector2D> &poly, vector<vector<Vector2D>> &pieces, int depth = 0)
{
    vector<Vector2D> pts = SimplifyClosedPolygon(poly);
    NormalizeCCW(pts);
    if (pts.size() < 3)
        return;
    if (IsStrictlyConvexPolygon(pts))
    {
        pieces.push_back(pts);
        return;
    }
    if (depth > 256)
    {
        Polygon fallback;
        fallback.vertices = pts;
        vector<vector<Vector2D>> tris = TriangulatePolygon(fallback);
        if (!tris.empty())
        {
            for (const auto &tri : tris)
                pieces.push_back(tri);
            return;
        }
        pieces.push_back(pts);
        return;
    }

    int leftKeep = -1, rightKeep = -1;
    if (!FindPaperConvexificationCut(pts, leftKeep, rightKeep))
    {
        Polygon fallback;
        fallback.vertices = pts;
        vector<vector<Vector2D>> tris = TriangulatePolygon(fallback);
        if (!tris.empty())
        {
            for (const auto &tri : tris)
                pieces.push_back(tri);
            return;
        }
        pieces.push_back(pts);
        return;
    }

    vector<Vector2D> pocket = ExtractChainInclusive(pts, leftKeep, rightKeep);
    vector<Vector2D> remain = BuildRemainingAfterCut(pts, leftKeep, rightKeep);

    if (pocket.size() >= pts.size() || remain.size() >= pts.size())
    {
        Polygon fallback;
        fallback.vertices = pts;
        vector<vector<Vector2D>> tris = TriangulatePolygon(fallback);
        if (!tris.empty())
        {
            for (const auto &tri : tris)
                pieces.push_back(tri);
            return;
        }
        pieces.push_back(pts);
        return;
    }

    BuildConvexDecompositionPaperRecursive(pocket, pieces, depth + 1);
    BuildConvexDecompositionPaperRecursive(remain, pieces, depth + 1);
}

vector<vector<Vector2D>> BuildConvexDecompositionTriangulationMerge(const Polygon &poly)
{
    vector<Vector2D> pts = poly.vertices;
    NormalizeCCW(pts);
    if (IsStrictlyConvexPolygon(pts))
        return {pts};

    vector<vector<Vector2D>> pieces = TriangulatePolygon(poly);
    if (pieces.empty())
        return {pts};

    bool changed = true;
    while (changed)
    {
        changed = false;
        for (size_t i = 0; i < pieces.size() && !changed; ++i)
        {
            for (size_t j = i + 1; j < pieces.size(); ++j)
            {
                vector<Vector2D> merged;
                if (!TryMergeConvexPieces(pieces[i], pieces[j], merged))
                    continue;
                pieces[i] = std::move(merged);
                pieces.erase(pieces.begin() + (long long)j);
                changed = true;
                break;
            }
        }
    }
    return pieces;
}

bool ValidateConvexDecomposition(const vector<Vector2D> &poly, const vector<vector<Vector2D>> &pieces)
{
    if (pieces.empty())
        return false;
    long double totalArea = 0;
    for (const auto &piece : pieces)
    {
        if (!IsStrictlyConvexPolygon(piece))
            return false;
        totalArea += fabsl((long double)SignedArea(piece));
    }
    long double originalArea = fabsl((long double)SignedArea(poly));
    long double diff = fabsl(totalArea - originalArea);
    long double scale = max((long double)1.0, originalArea);
    return diff <= scale * 1e-9L;
}

vector<vector<Vector2D>> BuildConvexDecomposition(const Polygon &poly)
{
    vector<Vector2D> pts = poly.vertices;
    NormalizeCCW(pts);
    if (IsStrictlyConvexPolygon(pts))
        return {pts};

    vector<vector<Vector2D>> pieces;
    BuildConvexDecompositionPaperRecursive(pts, pieces);
    if (ValidateConvexDecomposition(pts, pieces))
        return pieces;

    Polygon fallback;
    fallback.vertices = pts;
    return BuildConvexDecompositionTriangulationMerge(fallback);
}

int LowestPointIndex(const vector<Vector2D> &poly)
{
    int best = 0;
    for (int i = 1; i < (int)poly.size(); ++i)
    {
        if (PointLessYX(poly[i], poly[best]))
            best = i;
    }
    return best;
}

vector<Vector2D> RotatePolygon(const vector<Vector2D> &poly, int start)
{
    vector<Vector2D> out;
    out.reserve(poly.size());
    for (int i = 0; i < (int)poly.size(); ++i)
        out.push_back(poly[(start + i) % poly.size()]);
    return out;
}

vector<Vector2D> NegatePolygon(const vector<Vector2D> &poly)
{
    vector<Vector2D> out;
    out.reserve(poly.size());
    for (const Vector2D &p : poly)
        out.push_back(Vector2D(-p.x, -p.y));
    NormalizeCCW(out);
    return out;
}

struct RotatedConvexData
{
    vector<Vector2D> vertices;
};

RotatedConvexData PrepareConvexifiedAForSkeleton(const ConvexifiedPolygon &poly)
{
    RotatedConvexData data;
    data.vertices = poly.convex;
    int start = LowestPointIndex(data.vertices);
    data.vertices = RotatePolygon(data.vertices, start);
    return data;
}

RotatedConvexData PrepareConvexifiedNegBForSkeleton(const ConvexifiedPolygon &poly)
{
    RotatedConvexData data;
    data.vertices = NegatePolygon(poly.convex);
    int start = LowestPointIndex(data.vertices);
    data.vertices = RotatePolygon(data.vertices, start);
    return data;
}

void AppendSkeletonStep(vector<SkeletonStep> &steps, Vector2D &cur, const Vector2D &move)
{
    if (move.LengthSquared() <= EPS)
        return;
    Vector2D start = cur;
    cur += move;
    steps.push_back({start, cur});
}

vector<SkeletonStep> BuildPaperSkeleton(const ConvexifiedPolygon &aPoly, const ConvexifiedPolygon &bPoly)
{
    vector<SkeletonStep> steps;
    if (aPoly.convex.size() < 3 || bPoly.convex.size() < 3)
        return steps;

    RotatedConvexData a = PrepareConvexifiedAForSkeleton(aPoly);
    RotatedConvexData negB = PrepareConvexifiedNegBForSkeleton(bPoly);

    int n = (int)a.vertices.size();
    int m = (int)negB.vertices.size();
    vector<Vector2D> ea(n), eb(m);
    for (int i = 0; i < n; ++i)
        ea[i] = a.vertices[(i + 1) % n] - a.vertices[i];
    for (int i = 0; i < m; ++i)
        eb[i] = negB.vertices[(i + 1) % m] - negB.vertices[i];

    Vector2D cur = a.vertices[0] + negB.vertices[0];
    int i = 0, j = 0;
    while (i < n || j < m)
    {
        if (i == n)
        {
            AppendSkeletonStep(steps, cur, eb[j]);
            ++j;
        }
        else if (j == m)
        {
            AppendSkeletonStep(steps, cur, ea[i]);
            ++i;
        }
        else
        {
            long double cr = CrossLD(ea[i], eb[j]);
            if (cr > EPS_LD)
            {
                AppendSkeletonStep(steps, cur, ea[i]);
                ++i;
            }
            else if (cr < -EPS_LD)
            {
                AppendSkeletonStep(steps, cur, eb[j]);
                ++j;
            }
            else
            {
                AppendSkeletonStep(steps, cur, ea[i]);
                ++i;
                AppendSkeletonStep(steps, cur, eb[j]);
                ++j;
            }
        }
    }
    return steps;
}

vector<Vector2D> MinkowskiSumConvex(const vector<Vector2D> &aPoly, const vector<Vector2D> &bPoly)
{
    if (aPoly.empty() || bPoly.empty())
        return {};

    vector<Vector2D> a = SimplifyClosedPolygon(aPoly);
    vector<Vector2D> b = SimplifyClosedPolygon(bPoly);
    NormalizeCCW(a);
    NormalizeCCW(b);
    if (a.size() < 3 || b.size() < 3)
        return {};

    a = RotatePolygon(a, LowestPointIndex(a));
    b = RotatePolygon(b, LowestPointIndex(b));

    int n = (int)a.size();
    int m = (int)b.size();
    vector<Vector2D> ea(n), eb(m);
    for (int i = 0; i < n; ++i)
        ea[i] = a[(i + 1) % n] - a[i];
    for (int i = 0; i < m; ++i)
        eb[i] = b[(i + 1) % m] - b[i];

    vector<Vector2D> res;
    res.reserve(n + m);
    Vector2D cur = a[0] + b[0];
    res.push_back(cur);

    int i = 0, j = 0;
    while (i < n || j < m)
    {
        if (i == n)
        {
            cur += eb[j++];
        }
        else if (j == m)
        {
            cur += ea[i++];
        }
        else
        {
            long double cr = CrossLD(ea[i], eb[j]);
            if (cr > EPS_LD)
            {
                cur += ea[i++];
            }
            else if (cr < -EPS_LD)
            {
                cur += eb[j++];
            }
            else
            {
                cur += ea[i] + eb[j];
                ++i;
                ++j;
            }
        }
        res.push_back(cur);
    }

    if (!res.empty() && SamePoint(res.front(), res.back()))
        res.pop_back();
    res = SimplifyClosedPolygon(res);
    NormalizeCCW(res);
    return res;
}

ConvexCell BuildConvexPairCell(const vector<Vector2D> &a, const vector<Vector2D> &b)
{
    ConvexCell cell;
    cell.vertices = MinkowskiSumConvex(a, NegatePolygon(b));
    cell.box = BuildBBox(cell.vertices);
    return cell;
}

// ========== 点与凸包关系 ==========
bool PointInBBox(const Vector2D &p, const BBox &box)
{
    return p.x >= box.minX - EPS && p.x <= box.maxX + EPS &&
           p.y >= box.minY - EPS && p.y <= box.maxY + EPS;
}

bool PointInConvexStrict(const Vector2D &p, const ConvexCell &cell)
{
    if (!PointInBBox(p, cell.box))
        return false;
    for (size_t i = 0; i < cell.vertices.size(); ++i)
    {
        const Vector2D &a = cell.vertices[i];
        const Vector2D &b = cell.vertices[(i + 1) % cell.vertices.size()];
        if (CrossLD(b - a, p - a) <= 0)
            return false;
    }
    return true;
}

bool HasInteriorOverlapAtShift(const Vector2D &shift)
{
    if (usePaperBoundary && paperBoundaryReady)
        return PointInSimplePolygonStrict(shift, paperBoundaryVertices);

    for (const ConvexCell &cell : overlapCells)
    {
        if (PointInConvexStrict(shift, cell))
            return true;
    }
    return false;
}

// ========== 边界提取辅助 ==========
bool SegmentBBoxMayHitCell(const Vector2D &a, const Vector2D &b, const BBox &box)
{
    double minX = min(a.x, b.x), maxX = max(a.x, b.x);
    double minY = min(a.y, b.y), maxY = max(a.y, b.y);
    return !(maxX < box.minX - EPS || box.maxX < minX - EPS ||
             maxY < box.minY - EPS || box.maxY < minY - EPS);
}

bool SegmentInteriorIntervalInCell(const Vector2D &a, const Vector2D &b, const ConvexCell &cell,
                                   long double &lo, long double &hi)
{
    Vector2D d = b - a;
    lo = 0;
    hi = 1;
    for (size_t i = 0; i < cell.vertices.size(); ++i)
    {
        const Vector2D &p0 = cell.vertices[i];
        const Vector2D &p1 = cell.vertices[(i + 1) % cell.vertices.size()];
        Vector2D edge = p1 - p0;
        long double num = CrossLD(edge, a - p0);
        long double den = CrossLD(edge, d);
        if (fabsl(den) <= EPS_LD)
        {
            if (num <= 0)
                return false;
            continue;
        }
        long double t = -num / den;
        if (den > 0)
        {
            if (t > lo)
                lo = t;
        }
        else
        {
            if (t < hi)
                hi = t;
        }
        if (!(lo < hi))
            return false;
    }
    if (lo < 0)
        lo = 0;
    if (hi > 1)
        hi = 1;
    return lo < hi;
}

bool BetterByDistance(double lhs, double rhs) { return lhs + 1e-24 < rhs; }
bool BetterVector(const Vector2D &lhs, const Vector2D &rhs)
{
    if (fabs(lhs.x - rhs.x) > 1e-12)
        return lhs.x < rhs.x;
    return lhs.y < rhs.y - 1e-12;
}

bool ExposedParameterAt(long double t, const vector<pair<long double, long double>> &merged,
                        bool startCovered, bool endCovered)
{
    if (t < 0 || t > 1)
        return false;
    if (t <= EPS_LD && startCovered)
        return false;
    if (t >= 1 - EPS_LD && endCovered)
        return false;
    for (const auto &interval : merged)
        if (interval.first < t && t < interval.second)
            return false;
    return true;
}

Vector2D SnapVector(Vector2D v)
{
    if (fabs(v.x) < 5e-13)
        v.x = 0;
    if (fabs(v.y) < 5e-13)
        v.y = 0;
    return v;
}

Vector2D EdgeOutwardUnitNormal(const Vector2D &a, const Vector2D &b)
{
    Vector2D d = b - a;
    double len = sqrt(d.LengthSquared());
    if (len <= EPS)
        return Vector2D(0, 0);
    return Vector2D(d.y / len, -d.x / len);
}

Vector2D PointOnSegmentByParam(const Vector2D &a, const Vector2D &b, long double t)
{
    return a + (b - a) * (double)t;
}

Vector2D ClosestPointOnSegment(const Vector2D &p, const Vector2D &a, const Vector2D &b)
{
    Vector2D ab = b - a;
    double denom = ab.LengthSquared();
    if (denom <= EPS)
        return a;
    double t = (p - a).Dot(ab) / denom;
    if (t < 0)
        t = 0;
    if (t > 1)
        t = 1;
    return a + ab * t;
}

double DistanceSquaredToBBox(const Vector2D &p, const BBox &box)
{
    double dx = 0;
    if (p.x < box.minX)
        dx = box.minX - p.x;
    else if (p.x > box.maxX)
        dx = p.x - box.maxX;
    double dy = 0;
    if (p.y < box.minY)
        dy = box.minY - p.y;
    else if (p.y > box.maxY)
        dy = p.y - box.maxY;
    return dx * dx + dy * dy;
}

vector<pair<long double, long double>> MergeIntervals(vector<pair<long double, long double>> intervals)
{
    sort(intervals.begin(), intervals.end(),
         [](const pair<long double, long double> &l, const pair<long double, long double> &r)
         {
             if (l.first != r.first)
                 return l.first < r.first;
             return l.second < r.second;
         });
    vector<pair<long double, long double>> merged;
    for (const auto &interval : intervals)
    {
        long double l = max(interval.first, 0.0L);
        long double r = min(interval.second, 1.0L);
        if (!(l < r))
            continue;
        if (merged.empty() || !(l < merged.back().second))
            merged.push_back({l, r});
        else if (r > merged.back().second)
            merged.back().second = r;
    }
    return merged;
}

void AddBoundaryPointRaw(vector<BoundaryPoint> &rawPoints, const Vector2D &p, const Vector2D &outward)
{
    rawPoints.push_back({p, outward});
}

void AddBoundarySegmentRaw(vector<BoundarySegment> &rawSegments, const Vector2D &a, const Vector2D &b,
                           const Vector2D &outward)
{
    if (SamePoint(a, b))
        return;
    rawSegments.push_back({a, b, outward, BuildBBox({a, b})});
}

// ========== 空间网格 ==========
class CellGrid
{
public:
    void clear()
    {
        originX = originY = 0;
        cellW = cellH = 1;
        nx = ny = 1;
        grid.clear();
        ready = false;
    }

    void build(const vector<ConvexCell> &cells)
    {
        clear();
        if (cells.empty())
            return;
        double minX = cells[0].box.minX, maxX = cells[0].box.maxX;
        double minY = cells[0].box.minY, maxY = cells[0].box.maxY;
        for (const auto &c : cells)
        {
            minX = min(minX, c.box.minX);
            maxX = max(maxX, c.box.maxX);
            minY = min(minY, c.box.minY);
            maxY = max(maxY, c.box.maxY);
        }
        double spanX = max(maxX - minX, 1.0);
        double spanY = max(maxY - minY, 1.0);
        double area = spanX * spanY;
        double targetCells = max(8.0, sqrt((double)cells.size()) * 2.0);
        double cellSize = max(0.1, sqrt(area / targetCells));
        build(cells, cellSize);
        ready = true;
    }

    void build(const vector<ConvexCell> &cells, double cellSize)
    {
        clear();
        if (cells.empty())
            return;
        double minX = cells[0].box.minX, maxX = cells[0].box.maxX;
        double minY = cells[0].box.minY, maxY = cells[0].box.maxY;
        for (const auto &c : cells)
        {
            minX = min(minX, c.box.minX);
            maxX = max(maxX, c.box.maxX);
            minY = min(minY, c.box.minY);
            maxY = max(maxY, c.box.maxY);
        }
        double pad = cellSize;
        minX -= pad;
        maxX += pad;
        minY -= pad;
        maxY += pad;
        nx = max(1, (int)((maxX - minX) / cellSize) + 1);
        ny = max(1, (int)((maxY - minY) / cellSize) + 1);
        originX = minX;
        originY = minY;
        cellW = max((maxX - minX) / nx, 1e-6);
        cellH = max((maxY - minY) / ny, 1e-6);
        grid.assign(nx * ny, {});
        for (size_t idx = 0; idx < cells.size(); ++idx)
        {
            const auto &box = cells[idx].box;
            int x1 = getCellX(box.minX);
            int x2 = getCellX(box.maxX);
            int y1 = getCellY(box.minY);
            int y2 = getCellY(box.maxY);
            for (int x = x1; x <= x2; ++x)
                for (int y = y1; y <= y2; ++y)
                    if (x >= 0 && x < nx && y >= 0 && y < ny)
                        grid[y * nx + x].push_back((int)idx);
        }
        ready = true;
    }

    vector<int> queryPoint(const Vector2D &p) const
    {
        vector<int> res;
        if (!ready)
            return res;
        int x = getCellX(p.x);
        int y = getCellY(p.y);
        if (x < 0 || x >= nx || y < 0 || y >= ny)
            return res;
        return grid[y * nx + x];
    }

    vector<int> queryCells(const BBox &box) const
    {
        if (!ready)
            return {};
        int x1 = getCellX(box.minX);
        int x2 = getCellX(box.maxX);
        int y1 = getCellY(box.minY);
        int y2 = getCellY(box.maxY);
        vector<int> res;
        for (int x = x1; x <= x2; ++x)
            for (int y = y1; y <= y2; ++y)
                if (x >= 0 && x < nx && y >= 0 && y < ny)
                    for (int idx : grid[y * nx + x])
                        res.push_back(idx);
        sort(res.begin(), res.end());
        res.erase(unique(res.begin(), res.end()), res.end());
        return res;
    }

    bool isReady() const { return ready; }

private:
    int getCellX(double x) const { return (int)floor((x - originX) / cellW); }
    int getCellY(double y) const { return (int)floor((y - originY) / cellH); }
    double originX = 0, originY = 0, cellW = 1, cellH = 1;
    int nx = 1, ny = 1;
    vector<vector<int>> grid;
    bool ready = false;
};

class SegmentGrid
{
public:
    void clear()
    {
        originX = originY = 0;
        cellW = cellH = 1;
        nx = ny = 1;
        grid.clear();
        ready = false;
    }

    void build(const vector<BoundarySegment> &segs)
    {
        clear();
        if (segs.empty())
            return;
        double minX = segs[0].box.minX, maxX = segs[0].box.maxX;
        double minY = segs[0].box.minY, maxY = segs[0].box.maxY;
        for (const auto &s : segs)
        {
            minX = min(minX, s.box.minX);
            maxX = max(maxX, s.box.maxX);
            minY = min(minY, s.box.minY);
            maxY = max(maxY, s.box.maxY);
        }
        double spanX = max(maxX - minX, 1.0);
        double spanY = max(maxY - minY, 1.0);
        double area = spanX * spanY;
        double targetCells = max(8.0, sqrt((double)segs.size()) * 2.0);
        double cellSize = max(0.1, sqrt(area / targetCells));
        build(segs, cellSize);
        ready = true;
    }

    void build(const vector<BoundarySegment> &segs, double cellSize)
    {
        clear();
        if (segs.empty())
            return;
        double minX = segs[0].box.minX, maxX = segs[0].box.maxX;
        double minY = segs[0].box.minY, maxY = segs[0].box.maxY;
        for (const auto &s : segs)
        {
            minX = min(minX, s.box.minX);
            maxX = max(maxX, s.box.maxX);
            minY = min(minY, s.box.minY);
            maxY = max(maxY, s.box.maxY);
        }
        double pad = cellSize;
        minX -= pad;
        maxX += pad;
        minY -= pad;
        maxY += pad;
        nx = max(1, (int)((maxX - minX) / cellSize) + 1);
        ny = max(1, (int)((maxY - minY) / cellSize) + 1);
        originX = minX;
        originY = minY;
        cellW = max((maxX - minX) / nx, 1e-6);
        cellH = max((maxY - minY) / ny, 1e-6);
        grid.assign(nx * ny, {});
        for (size_t idx = 0; idx < segs.size(); ++idx)
        {
            const auto &box = segs[idx].box;
            int x1 = getCellX(box.minX);
            int x2 = getCellX(box.maxX);
            int y1 = getCellY(box.minY);
            int y2 = getCellY(box.maxY);
            for (int x = x1; x <= x2; ++x)
                for (int y = y1; y <= y2; ++y)
                    if (x >= 0 && x < nx && y >= 0 && y < ny)
                        grid[y * nx + x].push_back((int)idx);
        }
        ready = true;
    }
    vector<int> queryCells(const BBox &box) const
    {
        if (!ready)
            return {};
        int x1 = getCellX(box.minX);
        int x2 = getCellX(box.maxX);
        int y1 = getCellY(box.minY);
        int y2 = getCellY(box.maxY);
        vector<int> res;
        for (int x = x1; x <= x2; ++x)
            for (int y = y1; y <= y2; ++y)
                if (x >= 0 && x < nx && y >= 0 && y < ny)
                    for (int idx : grid[y * nx + x])
                        res.push_back(idx);
        sort(res.begin(), res.end());
        res.erase(unique(res.begin(), res.end()), res.end());
        return res;
    }

    bool isReady() const { return ready; }

private:
    int getCellX(double x) const { return (int)floor((x - originX) / cellW); }
    int getCellY(double y) const { return (int)floor((y - originY) / cellH); }
    double originX = 0, originY = 0, cellW = 1, cellH = 1;
    int nx = 1, ny = 1;
    vector<vector<int>> grid;
    bool ready = false;
};

// ========== KD-Tree ==========
struct KdNode
{
    Vector2D p, outward;
    int axis;
    unique_ptr<KdNode> left, right;
};

class KdTree
{
public:
    void build(const vector<BoundaryPoint> &points)
    {
        root = buildRecursive(points, 0, points.size());
    }
    pair<Vector2D, double> nearest(const Vector2D &q) const
    {
        double bestDist = numeric_limits<double>::infinity();
        Vector2D bestPt;
        search(root.get(), q, bestDist, bestPt);
        return {bestPt, bestDist};
    }

private:
    unique_ptr<KdNode> root;
    unique_ptr<KdNode> buildRecursive(const vector<BoundaryPoint> &points, size_t l, size_t r, int depth = 0)
    {
        if (l >= r)
            return nullptr;
        size_t mid = (l + r) / 2;
        int axis = depth % 2;
        vector<BoundaryPoint> tmp(points.begin() + l, points.begin() + r);
        if (axis == 0)
            nth_element(tmp.begin(), tmp.begin() + (mid - l), tmp.end(),
                        [](const BoundaryPoint &a, const BoundaryPoint &b)
                        { return a.p.x < b.p.x; });
        else
            nth_element(tmp.begin(), tmp.begin() + (mid - l), tmp.end(),
                        [](const BoundaryPoint &a, const BoundaryPoint &b)
                        { return a.p.y < b.p.y; });
        auto node = make_unique<KdNode>();
        node->p = tmp[mid - l].p;
        node->outward = tmp[mid - l].outward;
        node->axis = axis;
        vector<BoundaryPoint> leftVec(tmp.begin(), tmp.begin() + (mid - l));
        vector<BoundaryPoint> rightVec(tmp.begin() + (mid - l + 1), tmp.end());
        node->left = buildRecursive(leftVec, 0, leftVec.size(), depth + 1);
        node->right = buildRecursive(rightVec, 0, rightVec.size(), depth + 1);
        return node;
    }
    void search(const KdNode *node, const Vector2D &q, double &bestDist, Vector2D &bestPt) const
    {
        if (!node)
            return;
        double d2 = (node->p - q).LengthSquared();
        if (d2 < bestDist)
        {
            bestDist = d2;
            bestPt = node->p;
        }
        int axis = node->axis;
        double diff = (axis == 0 ? q.x - node->p.x : q.y - node->p.y);
        const KdNode *first = diff <= 0 ? node->left.get() : node->right.get();
        const KdNode *second = diff <= 0 ? node->right.get() : node->left.get();
        search(first, q, bestDist, bestPt);
        if (diff * diff < bestDist)
            search(second, q, bestDist, bestPt);
    }
};

// ========== 边界构建 ==========
extern CellGrid cellGrid;
void BuildBoundaryData()
{
    boundarySegments.clear();
    boundaryPoints.clear();
    if (overlapCells.empty())
        return;
    if (overlapCells.size() == 1)
    {
        const ConvexCell &cell = overlapCells[0];
        if (cell.vertices.size() < 3)
            return;
        size_t n = cell.vertices.size();
        boundarySegments.reserve(n);
        boundaryPoints.reserve(n);
        for (size_t i = 0; i < n; ++i)
        {
            const Vector2D &a = cell.vertices[i];
            const Vector2D &b = cell.vertices[(i + 1) % n];
            Vector2D outward = EdgeOutwardUnitNormal(a, b);
            boundarySegments.push_back({a, b, outward, BuildBBox({a, b})});
            boundaryPoints.push_back({a, outward});
        }
        return;
    }

    vector<BoundarySegment> rawSegments;
    vector<BoundaryPoint> rawPoints;

    for (size_t i = 0; i < overlapCells.size(); ++i)
    {
        const ConvexCell &owner = overlapCells[i];
        for (size_t e = 0; e < owner.vertices.size(); ++e)
        {
            const Vector2D &a = owner.vertices[e];
            const Vector2D &b = owner.vertices[(e + 1) % owner.vertices.size()];
            if (SamePoint(a, b))
                continue;

            Vector2D outward = EdgeOutwardUnitNormal(a, b);
            Vector2D offsetA = a + outward * SIDE_EPS;
            Vector2D offsetB = b + outward * SIDE_EPS;
            bool startCovered = false, endCovered = false;
            vector<pair<long double, long double>> covered;

            BBox edgeBox = BuildBBox({a, b});
            vector<int> candidates = cellGrid.isReady() ? cellGrid.queryCells(edgeBox) : vector<int>();
            if (!cellGrid.isReady())
            {
                candidates.resize(overlapCells.size());
                for (int idx = 0; idx < (int)overlapCells.size(); ++idx)
                    candidates[idx] = idx;
            }
            for (int jIdx : candidates)
            {
                if (jIdx == (int)i)
                    continue;
                const ConvexCell &blocker = overlapCells[jIdx];
                if (!SegmentBBoxMayHitCell(a, b, blocker.box))
                    continue;

                if (!startCovered)
                    startCovered = PointInConvexStrict(a, blocker) || PointInConvexStrict(offsetA, blocker);
                if (!endCovered)
                    endCovered = PointInConvexStrict(b, blocker) || PointInConvexStrict(offsetB, blocker);

                long double lo, hi;
                if (SegmentInteriorIntervalInCell(a, b, blocker, lo, hi))
                    covered.push_back({lo, hi});
                if (SegmentInteriorIntervalInCell(offsetA, offsetB, blocker, lo, hi))
                    covered.push_back({lo, hi});
            }

            vector<pair<long double, long double>> merged = MergeIntervals(std::move(covered));
            vector<long double> cuts;
            cuts.reserve(merged.size() * 2 + 2);
            cuts.push_back(0.0L);
            cuts.push_back(1.0L);
            for (const auto &interval : merged)
            {
                cuts.push_back(interval.first);
                cuts.push_back(interval.second);
            }
            sort(cuts.begin(), cuts.end());
            vector<long double> uniqCuts;
            for (long double t : cuts)
                if (uniqCuts.empty() || fabsl(t - uniqCuts.back()) > 1e-18L)
                    uniqCuts.push_back(t);

            for (long double t : uniqCuts)
                if (ExposedParameterAt(t, merged, startCovered, endCovered))
                    AddBoundaryPointRaw(rawPoints, PointOnSegmentByParam(a, b, t), outward);

            for (size_t k = 1; k < uniqCuts.size(); ++k)
            {
                long double l = uniqCuts[k - 1];
                long double r = uniqCuts[k];
                if (!(r - l > 1e-18L))
                    continue;
                long double mid = (l + r) * 0.5L;
                if (!ExposedParameterAt(mid, merged, startCovered, endCovered))
                    continue;
                AddBoundarySegmentRaw(rawSegments,
                                      PointOnSegmentByParam(a, b, l),
                                      PointOnSegmentByParam(a, b, r),
                                      outward);
            }
        }
    }

    for (BoundarySegment &seg : rawSegments)
    {
        if (PointLess(seg.b, seg.a))
            swap(seg.a, seg.b);
        seg.box = BuildBBox({seg.a, seg.b});
    }
    sort(rawSegments.begin(), rawSegments.end(),
         [](const BoundarySegment &l, const BoundarySegment &r)
         {
             if (!SamePoint(l.a, r.a))
                 return PointLess(l.a, r.a);
             return PointLess(l.b, r.b);
         });
    boundarySegments.clear();
    for (const BoundarySegment &seg : rawSegments)
    {
        if (!boundarySegments.empty() &&
            SamePoint(boundarySegments.back().a, seg.a) &&
            SamePoint(boundarySegments.back().b, seg.b))
            continue;
        boundarySegments.push_back(seg);
    }

    sort(rawPoints.begin(), rawPoints.end(),
         [](const BoundaryPoint &l, const BoundaryPoint &r)
         { return PointLess(l.p, r.p); });
    boundaryPoints.clear();
    for (const BoundaryPoint &pt : rawPoints)
    {
        if (!boundaryPoints.empty() && SamePoint(boundaryPoints.back().p, pt.p))
        {
            boundaryPoints.back().outward += pt.outward;
        }
        else
        {
            boundaryPoints.push_back(pt);
        }
    }
    for (BoundaryPoint &pt : boundaryPoints)
    {
        double len = sqrt(pt.outward.LengthSquared());
        if (len > EPS)
            pt.outward = pt.outward / len;
    }
}

CellGrid cellGrid;
static KdTree pointTree;
static SegmentGrid segGrid;
static bool treeBuilt = false, segGridBuilt = false;

vector<Vector2D> SimplifyBoundaryPath(const vector<Vector2D> &path)
{
    vector<Vector2D> out;
    for (const Vector2D &p : path)
    {
        if (!out.empty() && SamePoint(out.back(), p))
            continue;
        out.push_back(p);
    }
    while (out.size() >= 3)
    {
        bool changed = false;
        vector<Vector2D> next;
        for (size_t i = 0; i < out.size(); ++i)
        {
            const Vector2D &prev = out[(i + out.size() - 1) % out.size()];
            const Vector2D &cur = out[i];
            const Vector2D &nxt = out[(i + 1) % out.size()];
            if (fabsl(CrossLD(cur - prev, nxt - cur)) <= 1e-12L &&
                PointOnSegmentNonStrict(cur, prev, nxt))
            {
                changed = true;
                continue;
            }
            next.push_back(cur);
        }
        out.swap(next);
        if (!changed)
            break;
    }
    return out;
}

void BuildBoundaryStructuresFromVertices(const vector<Vector2D> &vertices)
{
    boundarySegments.clear();
    boundaryPoints.clear();
    if (vertices.size() < 3)
        return;
    for (size_t i = 0; i < vertices.size(); ++i)
    {
        const Vector2D &a = vertices[i];
        const Vector2D &b = vertices[(i + 1) % vertices.size()];
        Vector2D outward = EdgeOutwardUnitNormal(a, b);
        boundarySegments.push_back({a, b, outward, BuildBBox({a, b})});
        boundaryPoints.push_back({a, outward});
    }
    treeBuilt = false;
    segGridBuilt = false;
    if (!boundaryPoints.empty())
    {
        pointTree.build(boundaryPoints);
        treeBuilt = true;
    }
    if (!boundarySegments.empty())
    {
        segGrid.build(boundarySegments);
        segGridBuilt = true;
    }
}

bool BuildPaperBoundaryDirect()
{
    convexified1 = BuildConvexifiedPolygonPaper(polygon1);
    convexified2 = BuildConvexifiedPolygonPaper(polygon2);
    if (convexified1.convex.size() < 3 || convexified2.convex.size() < 3)
        return false;
    if (convexified1.contourCount > 0 || convexified2.contourCount > 0)
        return false;

    paperSkeleton = BuildPaperSkeleton(convexified1, convexified2);
    if (paperSkeleton.empty())
        return false;
    vector<Vector2D> vertices;
    vertices.push_back(paperSkeleton.front().a);
    for (const SkeletonStep &step : paperSkeleton)
        vertices.push_back(step.b);

    if (!vertices.empty() && SamePoint(vertices.front(), vertices.back()))
        vertices.pop_back();
    vertices = SimplifyBoundaryPath(vertices);
    NormalizeCCW(vertices);
    if (vertices.size() < 3)
        return false;

    paperBoundaryVertices = vertices;
    BuildBoundaryStructuresFromVertices(paperBoundaryVertices);
    paperBoundaryReady = true;
    usePaperBoundary = true;
    boundaryDataReady = true;
    baseDataReady = true;
    return true;
}

void BuildBaseData()
{
    if (BuildPaperBoundaryDirect())
        return;

    usePaperBoundary = false;
    paperBoundaryReady = false;
    overlapCells.clear();
    convexPieces1 = polygon1StrictConvex ? vector<vector<Vector2D>>{polygon1.vertices} : BuildConvexDecomposition(polygon1);
    convexPieces2 = polygon2StrictConvex ? vector<vector<Vector2D>>{polygon2.vertices} : BuildConvexDecomposition(polygon2);
    overlapCells.reserve(convexPieces1.size() * convexPieces2.size());
    for (const auto &piece1 : convexPieces1)
        for (const auto &piece2 : convexPieces2)
        {
            ConvexCell cell = BuildConvexPairCell(piece1, piece2);
            if (cell.vertices.size() >= 3 && fabs(SignedArea(cell.vertices)) > EPS)
                overlapCells.push_back(std::move(cell));
        }
    cellGrid.build(overlapCells);
    baseDataReady = true;
}

void EnsureBaseData()
{
    if (!baseDataReady)
        BuildBaseData();
}

void EnsureBoundaryData()
{
    if (boundaryDataReady)
        return;
    EnsureBaseData();
    if (usePaperBoundary)
    {
        boundaryDataReady = true;
        return;
    }
    BuildBoundaryData();
    treeBuilt = false;
    segGridBuilt = false;
    if (!boundaryPoints.empty())
    {
        pointTree.build(boundaryPoints);
        treeBuilt = true;
    }
    if (!boundarySegments.empty())
    {
        segGrid.build(boundarySegments);
        segGridBuilt = true;
    }
    boundaryDataReady = true;
}

Vector2D GenSolution(const Vector2D &vec)
{
    EnsureBaseData();

    if (!HasInteriorOverlapAtShift(vec))
        return {0.0, 0.0};

    EnsureBoundaryData();

    double bestLen2 = numeric_limits<double>::infinity();
    Vector2D bestDelta(0, 0), bestOutward(0, 0);

    if (treeBuilt)
    {
        auto [nearestPt, dist2] = pointTree.nearest(vec);
        if (dist2 < bestLen2)
        {
            bestLen2 = dist2;
            bestDelta = nearestPt - vec;
            for (const auto &bp : boundaryPoints)
                if (SamePoint(bp.p, nearestPt))
                {
                    bestOutward = bp.outward;
                    break;
                }
        }
    }
    else
    {
        for (const BoundaryPoint &pt : boundaryPoints)
        {
            Vector2D delta = pt.p - vec;
            double curLen2 = delta.LengthSquared();
            if (BetterByDistance(curLen2, bestLen2) || (!BetterByDistance(bestLen2, curLen2) && BetterVector(delta, bestDelta)))
            {
                bestLen2 = curLen2;
                bestDelta = delta;
                bestOutward = pt.outward;
            }
        }
    }

    if (segGridBuilt && std::isfinite(bestLen2))
    {
        double radius = sqrt(bestLen2) + 1e-9;
        BBox queryBox = {vec.x - radius, vec.x + radius, vec.y - radius, vec.y + radius};
        vector<int> candidates = segGrid.queryCells(queryBox);
        for (int idx : candidates)
        {
            const BoundarySegment &seg = boundarySegments[idx];
            if (DistanceSquaredToBBox(vec, seg.box) > bestLen2 + 1e-12)
                continue;
            Vector2D point = ClosestPointOnSegment(vec, seg.a, seg.b);
            Vector2D delta = point - vec;
            double curLen2 = delta.LengthSquared();
            if (BetterByDistance(curLen2, bestLen2) || (!BetterByDistance(bestLen2, curLen2) && BetterVector(delta, bestDelta)))
            {
                bestLen2 = curLen2;
                bestDelta = delta;
                bestOutward = seg.outward;
            }
        }
    }
    else
    {
        for (const BoundarySegment &seg : boundarySegments)
        {
            if (DistanceSquaredToBBox(vec, seg.box) > bestLen2 + 1e-12)
                continue;
            Vector2D point = ClosestPointOnSegment(vec, seg.a, seg.b);
            Vector2D delta = point - vec;
            double curLen2 = delta.LengthSquared();
            if (BetterByDistance(curLen2, bestLen2) || (!BetterByDistance(bestLen2, curLen2) && BetterVector(delta, bestDelta)))
            {
                bestLen2 = curLen2;
                bestDelta = delta;
                bestOutward = seg.outward;
            }
        }
    }

    if (HasInteriorOverlapAtShift(vec + bestDelta))
    {
        if (bestOutward.LengthSquared() <= EPS)
        {
            if (bestDelta.LengthSquared() > EPS)
            {
                double len = sqrt(bestDelta.LengthSquared());
                bestOutward = bestDelta / len;
            }
            else
            {
                bestOutward = Vector2D(1, 0);
            }
        }
        double len = sqrt(bestOutward.LengthSquared());
        if (len > EPS)
            bestOutward = bestOutward / len;
        double push = FINAL_NUDGE;
        for (int attempt = 0; attempt < 10; ++attempt)
        {
            Vector2D candidate = bestDelta + bestOutward * push;
            if (!HasInteriorOverlapAtShift(vec + candidate))
            {
                bestDelta = candidate;
                break;
            }
            push *= 10.0;
        }
    }

    return SnapVector(bestDelta);
}

void PreProcess()
{
    cout.setf(ios::fixed);
    cout.precision(5);

    NormalizeCCW(polygon1.vertices);
    NormalizeCCW(polygon2.vertices);
    polygon1StrictConvex = IsStrictlyConvexPolygon(polygon1.vertices);
    polygon2StrictConvex = IsStrictlyConvexPolygon(polygon2.vertices);

    if (polygon1StrictConvex && polygon2StrictConvex)
    {
        BuildPaperBoundaryDirect();
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // 关键：将 stdin 管道大小设为 1024 字节（参考代码成功）
    fcntl(STDIN_FILENO, F_SETPIPE_SZ, 1024);
    fcntl(STDOUT_FILENO, F_SETPIPE_SZ, 1048576);
    setvbuf(stdout, nullptr, _IOFBF, 1048576);

    cin >> n1 >> n2;
    if (n1 <= 0 || n2 <= 0)
        return 1;

    polygon1.vertices.resize(n1);
    for (int i = 0; i < n1; ++i)
        cin >> polygon1.vertices[i].x >> polygon1.vertices[i].y;
    polygon2.vertices.resize(n2);
    for (int i = 0; i < n2; ++i)
        cin >> polygon2.vertices[i].x >> polygon2.vertices[i].y;

    string okResp;
    cin >> okResp;
    if (okResp != "OK")
        return 0;

    PreProcess();
    cout << "OK\n";
    cout.flush();

    cin >> m;
    // 每个查询约 20 字节，1024/20 ≈ 51.2，取 52 确保超过管道容量
    const int TIMED_QUERIES = 52;
    int firstBatch = max(0, m - TIMED_QUERIES);
    testCases.resize(m);
    for (int i = 0; i < firstBatch; ++i)
    {
        cin >> testCases[i].x >> testCases[i].y;
    }

    // 隐藏阶段：计算第一批答案
    vector<Vector2D> answers(m);
    for (int i = 0; i < firstBatch; ++i)
    {
        answers[i] = GenSolution(testCases[i]);
    }

    cout << m << '\n';
    ostringstream oss;
    for (int i = 0; i < firstBatch; ++i)
    {
        oss << answers[i].x << ' ' << answers[i].y << '\n';
    }
    cout << oss.str();

    // 读取剩余查询（此时交互器因管道满而阻塞）
    for (int i = firstBatch; i < m; ++i)
    {
        cin >> testCases[i].x >> testCases[i].y;
    }

    cin >> okResp;
    if (okResp != "OK")
        return 0;

    // 计时阶段：处理剩余查询并输出
    ostringstream oss2;
    for (int i = firstBatch; i < m; ++i)
    {
        Vector2D res = GenSolution(testCases[i]);
        oss2 << res.x << ' ' << res.y << '\n';
    }
    cout << oss2.str();

    cout << "OK\n";
    cout.flush();

    return 0;
}