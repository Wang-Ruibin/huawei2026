#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include <random>

using namespace std;

const double PI = acos(-1.0);
const double EPS = 1e-6;
const double eps = 1e-12;

struct Vector2D
{
    double x, y;
    Vector2D(double x = 0, double y = 0) : x(x), y(y) {}

    Vector2D operator+(const Vector2D &o) const { return {x + o.x, y + o.y}; }
    Vector2D operator-(const Vector2D &o) const { return {x - o.x, y - o.y}; }
    Vector2D operator*(double k) const { return {x * k, y * k}; }

    double Dot(const Vector2D &o) const { return x * o.x + y * o.y; }
    double Length() const { return sqrt(x * x + y * y); }

    Vector2D Normalize() const
    {
        double l = Length();
        if (l == 0)
            return *this;
        return {x / l, y / l};
    }

    Vector2D Perp() const { return {-y, x}; }
};

struct Polygon
{
    vector<Vector2D> vertices;

    Vector2D GetCenter() const
    {
        Vector2D c(0, 0);
        if (vertices.empty())
            return c;
        for (const auto &v : vertices)
            c = c + v;
        return c * (1.0 / vertices.size());
    }

    void MoveByVec(const Vector2D &vec)
    {
        for (auto &v : vertices)
            v = v + vec;
    }
};

double Cross(const Vector2D &a, const Vector2D &b)
{
    return a.x * b.y - a.y * b.x;
}

double Cross(const Vector2D &o, const Vector2D &a, const Vector2D &b)
{
    return Cross(a - o, b - o);
}

struct BBox
{
    double minX, maxX, minY, maxY;
};

Polygon polygon1, polygon2;
BBox bbox1, bbox2;

BBox GetBBox(const Polygon &poly)
{
    double minX = poly.vertices[0].x, maxX = poly.vertices[0].x;
    double minY = poly.vertices[0].y, maxY = poly.vertices[0].y;

    for (const auto &v : poly.vertices)
    {
        minX = min(minX, v.x);
        maxX = max(maxX, v.x);
        minY = min(minY, v.y);
        maxY = max(maxY, v.y);
    }
    return {minX, maxX, minY, maxY};
}

// 判断 polygon2 平移 vec 后，和 polygon1 的 AABB 是否仍可能相交
bool bboxOverlapFast(const Vector2D &vec)
{
    return !(bbox1.maxX + eps < bbox2.minX + vec.x ||
             bbox2.maxX + vec.x + eps < bbox1.minX ||
             bbox1.maxY + eps < bbox2.minY + vec.y ||
             bbox2.maxY + vec.y + eps < bbox1.minY);
}

bool OnSegment(const Vector2D &A, const Vector2D &B, const Vector2D &P)
{
    if (fabs(Cross(A, B, P)) > eps)
        return false;
    return (P.x >= min(A.x, B.x) - eps && P.x <= max(A.x, B.x) + eps &&
            P.y >= min(A.y, B.y) - eps && P.y <= max(A.y, B.y) + eps);
}

bool PointInPolygonStrict(const Vector2D &p, const Polygon &poly)
{
    bool inside = false;
    int n = (int)poly.vertices.size();

    for (int i = 0, j = n - 1; i < n; j = i++)
    {
        const auto &a = poly.vertices[i];
        const auto &b = poly.vertices[j];

        if (OnSegment(a, b, p))
            return false;

        if ((a.y > p.y) != (b.y > p.y))
        {
            double x = a.x + (b.x - a.x) * (p.y - a.y) / (b.y - a.y);
            if (x > p.x)
                inside = !inside;
        }
    }
    return inside;
}

bool SegmentsProperIntersect(const Vector2D &a, const Vector2D &b,
                             const Vector2D &c, const Vector2D &d)
{
    double d1 = Cross(a, b, c);
    double d2 = Cross(a, b, d);
    double d3 = Cross(c, d, a);
    double d4 = Cross(c, d, b);
    return (d1 * d2 < -eps && d3 * d4 < -eps);
}

bool check(const Polygon &P, const Polygon &Q, const Vector2D &vec)
{
    if (!bboxOverlapFast(vec))
        return true;

    const auto &vP = P.vertices;
    const auto &vQ = Q.vertices;

    int nP = (int)vP.size();
    int nQ = (int)vQ.size();

    for (int i = 0; i < nP; ++i)
    {
        const auto &a = vP[i];
        const auto &b = vP[(i + 1) % nP];
        for (int j = 0; j < nQ; ++j)
        {
            const auto &c = vQ[j];
            const auto &d = vQ[(j + 1) % nQ];
            if (SegmentsProperIntersect(a, b, c, d))
                return false;
        }
    }

    for (const auto &p : vP)
        if (PointInPolygonStrict(p, Q))
            return false;

    for (const auto &q : vQ)
        if (PointInPolygonStrict(q, P))
            return false;

    return true;
}

double GenSolution(const Vector2D &dir)
{
    double lo = 0.0, hi = 1.0;

    if (check(polygon1, polygon2, dir * 1e-3))
        hi = 1e-3;
    else
    {
        while (true)
        {
            if (check(polygon1, polygon2, dir * hi))
                break;
            hi *= 2.0;
            if (hi > 1e9)
                break;
        }
    }

    while (hi - lo > EPS)
    {
        double mid = (lo + hi) * 0.5;
        if (check(polygon1, polygon2, dir * mid))
            hi = mid;
        else
            lo = mid;
    }

    return hi;
}

vector<Vector2D> g_escapeDirs;
int kDirectionCount = 32;
int n1, n2, m;
vector<Vector2D> testCases;

// vector<Vector2D> BuildDirections()
// {
//     vector<Vector2D> dirs;

//     // 固定随机种子
//     std::mt19937 rng(123456);
//     std::uniform_real_distribution<double> dist(0.0, 2.0 * PI);

//     double base = dist(rng); // 固定一次随机角度

//     for (int i = 0; i < kDirectionCount; ++i)
//     {
//         double ang = base + 2.0 * PI * i / kDirectionCount;
//         dirs.emplace_back(cos(ang), sin(ang));
//     }

//     return dirs;
// }

vector<Vector2D> BuildDirections()
{
    struct Cand
    {
        double score; // 用边长平方衡量这条法向的重要性
        Vector2D dir;
        bool used;
        Cand() : score(-1.0), dir(0, 0), used(false) {}
    };

    const int BIN_CNT = 4 * kDirectionCount; // 128 个桶，足够细
    const double TWO_PI = 2.0 * PI;

    vector<Cand> bins(BIN_CNT);

    auto normAngle = [&](double ang) -> double
    {
        if (ang < 0)
            ang += TWO_PI;
        if (ang >= TWO_PI)
            ang -= TWO_PI;
        return ang;
    };

    auto addPoly = [&](const Polygon &poly)
    {
        int n = (int)poly.vertices.size();
        for (int i = 0; i < n; ++i)
        {
            Vector2D a = poly.vertices[i];
            Vector2D b = poly.vertices[(i + 1) % n];
            Vector2D e = b - a;

            double len2 = e.x * e.x + e.y * e.y;
            if (len2 < 1e-18)
                continue;

            Vector2D nrm = e.Perp().Normalize();

            double ang = atan2(nrm.y, nrm.x);
            ang = normAngle(ang);

            int bin = (int)(ang / TWO_PI * BIN_CNT);
            if (bin < 0)
                bin = 0;
            if (bin >= BIN_CNT)
                bin = BIN_CNT - 1;

            // 同一桶里只保留“最长边”的法向
            if (len2 > bins[bin].score)
            {
                bins[bin].score = len2;
                bins[bin].dir = nrm;
            }
        }
    };

    addPoly(polygon1);
    addPoly(polygon2);

    vector<Vector2D> cand;
    cand.reserve(BIN_CNT);

    // 桶本身已经按角度顺序，不需要排序
    for (int i = 0; i < BIN_CNT; ++i)
    {
        if (bins[i].score > 0)
            cand.push_back(bins[i].dir);
    }

    vector<Vector2D> dirs;
    dirs.reserve(kDirectionCount);

    // 如果候选足够多，按角度均匀抽样 32 个
    if ((int)cand.size() >= kDirectionCount)
    {
        for (int i = 0; i < kDirectionCount; ++i)
        {
            int idx = (long long)i * (int)cand.size() / kDirectionCount;
            if (idx >= (int)cand.size())
                idx = (int)cand.size() - 1;
            dirs.push_back(cand[idx]);
        }
    }
    else
    {
        // 候选不足时，先放入所有候选
        for (const auto &v : cand)
            dirs.push_back(v);

        // 再用固定 32 方向补齐，保证数量足够
        for (int i = 0; (int)dirs.size() < kDirectionCount; ++i)
        {
            double ang = TWO_PI * i / kDirectionCount;
            dirs.emplace_back(cos(ang), sin(ang));
        }
    }

    return dirs;
}

void PreProcess()
{
    bbox1 = GetBBox(polygon1);
    bbox2 = GetBBox(polygon2);

    int base = polygon1.vertices.size() + polygon2.vertices.size();
    kDirectionCount = max(8, (int)sqrt(base) * 4);
    kDirectionCount = min(kDirectionCount, 100);

    g_escapeDirs = BuildDirections();

    for (int i = 0; i < kDirectionCount; ++i)
    {
        Vector2D dir = g_escapeDirs[i].Normalize();
        double d = GenSolution(dir);
        g_escapeDirs[i] = dir * d;
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n1 >> n2;

    polygon1.vertices.resize(n1);
    for (int i = 0; i < n1; ++i)
        cin >> polygon1.vertices[i].x >> polygon1.vertices[i].y;

    polygon2.vertices.resize(n2);
    for (int i = 0; i < n2; ++i)
        cin >> polygon2.vertices[i].x >> polygon2.vertices[i].y;

    string ok;
    cin >> ok;

    PreProcess();

    cout << "OK\n";
    cout.flush();

    cin >> m;
    testCases.resize(m);

    for (int i = 0; i < m; ++i)
        cin >> testCases[i].x >> testCases[i].y;

    cin >> ok;

    cout << m << '\n';

    for (int i = 0; i < m; ++i)
    {
        const Vector2D &t = testCases[i];

        // O(1) 早停：polygon2 平移 t 后，AABB 都不重叠，直接输出零向量
        if (!bboxOverlapFast(t))
        {
            cout << fixed << setprecision(5) << 0.0 << " " << 0.0 << '\n';
            continue;
        }

        Vector2D res;
        double best = 1e100;

        for (int j = 0; j < kDirectionCount; ++j)
        {
            Vector2D tmp = g_escapeDirs[j] - t;
            double d = tmp.Length();
            if (d < best)
            {
                best = d;
                res = tmp;
            }
        }

        cout << fixed << setprecision(5) << res.x << " " << res.y << '\n';
    }

    cout << "OK\n";
    cout.flush();
    return 0;
}